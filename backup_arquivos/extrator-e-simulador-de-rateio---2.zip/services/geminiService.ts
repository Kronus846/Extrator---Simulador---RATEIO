import { GoogleGenAI, Type } from "@google/genai";
import type { ExtractedData } from '../types';

export async function extractDataFromImage(imageBase64: string): Promise<ExtractedData> {
    if (!process.env.API_KEY) {
        throw new Error("API_KEY environment variable not set.");
    }
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    const imagePart = {
        inlineData: {
            mimeType: 'image/png',
            data: imageBase64,
        },
    };

    const extractionPrompt = `
      Analise esta imagem de uma planilha de cálculo judicial. Sua tarefa é extrair os seguintes dados financeiros e retorná-los em formato JSON, seguindo estritamente o schema fornecido.

      1.  **valorBrutoReclamante**: Encontre o valor bruto total devido ao reclamante. Geralmente está no topo, identificado como "RECTE LÍQUIDO", "TOTAL BRUTO", ou similar.
      2.  **descontosReclamante**: Localize a seção de descontos do reclamante. Extraia cada item de desconto (como "INSS", "CONTRIBUIÇÃO SOCIAL", "IRRF", etc.) e seu respectivo valor. Ignore itens com valor zero.
      3.  **reclamadaDebitos**: Localize a lista de débitos da reclamada (credores). Extraia TODOS os débitos, incluindo o pagamento ao reclamante ("AUTOR / EXEQUENTE", "LÍQUIDO DEVIDO AO RECLAMANTE") e todos os honorários de advogados. IMPORTANTE: Ignore/exclua qualquer débito relacionado a "DANIEL CIDRAO" ou "DANIEL CIDRÃO".
      4.  **contribuicaoSocialTotal**: Encontre e extraia o valor total da contribuição social, geralmente identificado como "CONTRIBUIÇÃO SOCIAL SOBRE SALÁRIOS DEVIDOS".

      Seja preciso e retorne apenas os dados solicitados.
    `;

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: { parts: [imagePart, { text: extractionPrompt }] },
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    valorBrutoReclamante: { type: Type.NUMBER },
                    descontosReclamante: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                descricao: { type: Type.STRING },
                                valor: { type: Type.NUMBER },
                            },
                            required: ['descricao', 'valor']
                        },
                    },
                    reclamadaDebitos: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                descricao: { type: Type.STRING },
                                valor: { type: Type.NUMBER },
                            },
                             required: ['descricao', 'valor']
                        },
                    },
                    contribuicaoSocialTotal: { type: Type.NUMBER, nullable: true },
                },
                 required: ['valorBrutoReclamante', 'descontosReclamante', 'reclamadaDebitos']
            },
        },
    });

    const data: ExtractedData = JSON.parse(response.text);
    
    return data;
}