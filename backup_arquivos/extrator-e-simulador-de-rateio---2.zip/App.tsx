import React, { useState, useEffect, useCallback } from 'react';
import type { ExtractedData, RateioItem, Debito, Desconto } from './types';
import { extractDataFromImage } from './services/geminiService';
import { RateioModal } from './components/RateioModal';

// --- Helper Functions ---
const formatCurrency = (value: number | string): string => {
    if (typeof value === 'number') {
        return value.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }
    const digitsOnly = value.replace(/\D/g, '');
    if (digitsOnly === '') return '0,00';
    const numberValue = parseInt(digitsOnly, 10) / 100;
    return numberValue.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
};

const parseCurrency = (value: string): number => {
    if (!value) return 0;
    const numberString = value.replace(/\./g, '').replace(',', '.');
    return parseFloat(numberString) || 0;
};

// --- Helper Components ---

const WelcomePlaceholder: React.FC = () => (
    <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200 h-full flex flex-col justify-center items-center text-center">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-20 w-20 text-blue-300 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
        <h2 className="text-xl font-bold text-gray-800">Bem-vindo!</h2>
        <p className="text-gray-600 mt-2 max-w-sm">Para começar, anexe ou cole uma imagem da sua planilha de cálculo judicial na área à esquerda.</p>
        <p className="text-gray-500 mt-4 text-sm">A IA irá extrair os valores, que você poderá editar antes de simular o rateio.</p>
    </div>
);

interface EditableFieldProps {
    label: string;
    value: number;
    onChange: (newValue: number) => void;
    labelClassName?: string;
    valueClassName?: string;
}

const EditableField: React.FC<EditableFieldProps> = ({ label, value, onChange, labelClassName = "font-semibold text-gray-600", valueClassName = "font-mono text-lg font-semibold text-gray-800" }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [displayValue, setDisplayValue] = useState(formatCurrency(value));

    useEffect(() => {
        setDisplayValue(formatCurrency(value));
    }, [value]);

    const handleBlur = () => {
        setIsEditing(false);
        onChange(parseCurrency(displayValue));
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') {
            e.currentTarget.blur();
        }
    };
    
    if (isEditing) {
        return (
            <div className="flex justify-between items-baseline mb-2">
                <label className={labelClassName}>{label}:</label>
                <input
                    type="text"
                    value={displayValue}
                    onChange={(e) => setDisplayValue(formatCurrency(e.target.value))}
                    onBlur={handleBlur}
                    onKeyDown={handleKeyDown}
                    className="w-36 text-right px-2 py-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 font-mono text-lg"
                    autoFocus
                />
            </div>
        );
    }

    return (
        <div className="flex justify-between items-baseline mb-2" onClick={() => setIsEditing(true)} title="Clique para editar">
            <span className={labelClassName}>{label}:</span>
            <span className={`${valueClassName} cursor-pointer p-1 rounded-md hover:bg-gray-100`}>{formatCurrency(value)}</span>
        </div>
    );
};

interface EditableListItemProps {
    item: { descricao: string; valor: number };
    onDescriptionChange: (value: string) => void;
    onValueChange: (value: number) => void;
    onDelete: () => void;
    valueClassName?: string;
}

export const EditableListItem: React.FC<EditableListItemProps> = ({ item, onDescriptionChange, onValueChange, onDelete, valueClassName }) => {
    const [displayValue, setDisplayValue] = useState(formatCurrency(item.valor));

    useEffect(() => {
        setDisplayValue(formatCurrency(item.valor));
    }, [item.valor]);

    const handleValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        setDisplayValue(formatCurrency(value));
        onValueChange(parseCurrency(value));
    };

    return (
        <div className="flex items-center gap-2 p-2 bg-gray-50 rounded-md border border-gray-200">
            <input
                type="text"
                value={item.descricao}
                onChange={(e) => onDescriptionChange(e.target.value)}
                className="flex-grow px-2 py-1 border border-gray-300 rounded-md shadow-sm text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                placeholder="Descrição"
            />
            <input
                type="text"
                value={displayValue}
                onChange={handleValueChange}
                className={`w-32 px-2 py-1 border border-gray-300 rounded-md shadow-sm text-sm text-right font-mono focus:outline-none focus:ring-blue-500 focus:border-blue-500 ${valueClassName ?? ''}`}
                placeholder="R$ 0,00"
            />
            <button
                onClick={onDelete}
                className="text-gray-400 hover:text-red-600 p-1 rounded-full transition-colors flex-shrink-0"
                aria-label="Remover item"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
            </button>
        </div>
    );
};


// --- Main App Component ---

const App: React.FC = () => {
    const [image, setImage] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [extractedData, setExtractedData] = useState<ExtractedData | null>(null);
    const [isHovering, setIsHovering] = useState(false);
    const [showRateioConfig, setShowRateioConfig] = useState(false);
    const [rateioItems, setRateioItems] = useState<RateioItem[]>([]);

    useEffect(() => {
        try {
            const savedState = localStorage.getItem('appState');
            if (savedState) {
                const parsedState = JSON.parse(savedState);
                setImage(parsedState.image || null);
                setExtractedData(parsedState.extractedData || null);
            }
        } catch (e) {
            console.error("Failed to load state from localStorage:", e);
            localStorage.removeItem('appState');
        }
    }, []);

    useEffect(() => {
        try {
            const stateToSave = { image, extractedData };
            localStorage.setItem('appState', JSON.stringify(stateToSave));
        } catch (e) {
            console.error("Failed to save state to localStorage:", e);
        }
    }, [image, extractedData]);

    const handleFileChange = (file: File | null) => {
        if (file && file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setImage(reader.result as string);
                setExtractedData(null);
                setError(null);
            };
            reader.readAsDataURL(file);
        } else {
            setError("Por favor, selecione um arquivo de imagem válido.");
        }
    };

    const handlePaste = useCallback((e: ClipboardEvent) => {
        const items = e.clipboardData?.items;
        if (!items) return;
        for (let i = 0; i < items.length; i++) {
            if (items[i].type.indexOf('image') !== -1) {
                const blob = items[i].getAsFile();
                if (blob) handleFileChange(blob);
                break;
            }
        }
    }, []);

    useEffect(() => {
        window.addEventListener('paste', handlePaste);
        return () => window.removeEventListener('paste', handlePaste);
    }, [handlePaste]);

    const handleExtractData = async () => {
        if (!image) {
            setError("Por favor, anexe uma imagem primeiro.");
            return;
        }
        setIsLoading(true);
        setError(null);
        setExtractedData(null);
        try {
            const base64Data = image.split(',')[1];
            const data = await extractDataFromImage(base64Data);
            
            // Normalize data: ensure discounts and debits are positive values.
            data.descontosReclamante = data.descontosReclamante.map(d => ({ ...d, id: crypto.randomUUID(), valor: Math.abs(d.valor) }));
            data.reclamadaDebitos = data.reclamadaDebitos.map(d => ({ ...d, id: crypto.randomUUID(), valor: Math.abs(d.valor) }));

            setExtractedData(data);
        } catch (e) {
            console.error(e);
            const errorMessage = e instanceof Error ? e.message : "Erro desconhecido.";
            setError(`Não foi possível extrair os dados da imagem. Detalhe: ${errorMessage}`);
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleOpenRateioConfig = () => {
        if (!extractedData) return;
    
        const { valorBrutoReclamante, reclamadaDebitos, descontosReclamante, contribuicaoSocialTotal } = extractedData;
        const items: RateioItem[] = [];
    
        const totalDescontos = descontosReclamante.reduce((acc, d) => acc + d.valor, 0);
        const valorLiquidoCalculado = valorBrutoReclamante - totalDescontos;
    
        items.push({
            id: 'principal_reclamante_liquido',
            descricao: 'Crédito Líquido do Reclamante',
            valorOriginal: valorLiquidoCalculado,
            selecionado: true,
            origem: 'principal'
        });
    
        descontosReclamante.forEach(d => {
            items.push({ id: `reclamante_${d.descricao}`, descricao: d.descricao, valorOriginal: d.valor, selecionado: true, origem: 'reclamante' });
        });
    
        const outrosDebitosReclamada = reclamadaDebitos.filter(d => {
            const desc = d.descricao.toUpperCase();
            return !(desc.includes('AUTOR') || desc.includes('EXEQUENTE') || desc.includes('RECLAMANTE'));
        });
    
        const contribuicaoSegurado = descontosReclamante.find(d => d.descricao.toUpperCase().includes('CONTRIBUIÇÃO SOCIAL'));
        if (contribuicaoSegurado && contribuicaoSocialTotal && contribuicaoSocialTotal > contribuicaoSegurado.valor) {
            const valorEmpresa = contribuicaoSocialTotal - contribuicaoSegurado.valor;
            items.push({ id: `reclamada_cs_empresa`, descricao: 'Contribuição Social - Empresa', valorOriginal: valorEmpresa, selecionado: true, origem: 'reclamada' });
        }
    
        const debitsFinaisReclamada = outrosDebitosReclamada.filter(d => {
            const desc = d.descricao.toUpperCase();
            return !desc.includes('FGTS') && !desc.includes('CONTRIBUIÇÃO SOCIAL');
        });
    
        debitsFinaisReclamada.forEach(d => {
            items.push({ id: `reclamada_${d.descricao}`, descricao: d.descricao, valorOriginal: d.valor, selecionado: true, origem: 'reclamada' });
        });
    
        setRateioItems(items);
        setShowRateioConfig(true);
    };

    const handleUpdateExtractedData = (field: keyof ExtractedData, value: any) => {
        if (!extractedData) return;
        setExtractedData(prev => prev ? { ...prev, [field]: value } : null);
    };

    const handleUpdateListItem = (listName: 'descontosReclamante' | 'reclamadaDebitos', index: number, field: 'descricao' | 'valor', value: string | number) => {
        if (!extractedData) return;
        const newList = [...(extractedData[listName] as (Desconto[] | Debito[]))];
        const currentItem = newList[index];
        if (currentItem) {
            newList[index] = { ...currentItem, [field]: value };
            handleUpdateExtractedData(listName, newList);
        }
    };

    const handleDeleteListItem = (listName: 'descontosReclamante' | 'reclamadaDebitos', index: number) => {
        if (!extractedData) return;
        const newList = [...(extractedData[listName] as (Desconto[] | Debito[]))];
        newList.splice(index, 1);
        handleUpdateExtractedData(listName, newList);
    };

    const handleAddListItem = (listName: 'descontosReclamante' | 'reclamadaDebitos') => {
        if (!extractedData) return;
        const newItem = { id: crypto.randomUUID(), descricao: '', valor: 0 };
        const newList = [...(extractedData[listName] as (Desconto[] | Debito[])), newItem];
        handleUpdateExtractedData(listName, newList);
    };

    // --- Cálculos ---
    const subtotalDescontos = extractedData?.descontosReclamante.reduce((acc, d) => acc + d.valor, 0) ?? 0;
    const valorBrutoReclamante = extractedData?.valorBrutoReclamante ?? 0;
    const valorLiquidoFinal = valorBrutoReclamante - subtotalDescontos;


    return (
        <>
            <div className="bg-gray-50 min-h-screen text-gray-800 p-4 sm:p-8">
                <div className="max-w-7xl mx-auto">
                    <header className="text-center mb-8">
                        <h1 className="text-4xl font-bold text-gray-900">Extrator e Simulador de Rateio - 2</h1>
                        <p className="text-lg text-gray-600 mt-2">Anexe uma planilha de cálculo, extraia os dados e simule o rateio de depósitos.</p>
                    </header>

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                        {/* Coluna da Esquerda: Upload e Planilha */}
                        <div className="space-y-6">
                            {!image ? (
                                <div
                                    className="w-full p-10 border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center text-center cursor-pointer transition-all duration-300 hover:border-blue-500 hover:bg-blue-50"
                                    onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); setIsHovering(true);}}
                                    onDragLeave={(e) => { e.preventDefault(); e.stopPropagation(); setIsHovering(false);}}
                                    onDrop={(e) => { e.preventDefault(); e.stopPropagation(); setIsHovering(false); if (e.dataTransfer.files?.[0]) handleFileChange(e.dataTransfer.files[0]); }}
                                >
                                    <input type="file" className="hidden" id="file-upload" accept="image/*" onChange={(e) => handleFileChange(e.target.files?.[0] || null)} />
                                    <svg className="w-16 h-16 text-gray-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" /></svg>
                                    <p className="text-gray-600 font-semibold">{isHovering ? "Solte a imagem para anexar!" : "Arraste e solte uma imagem aqui"}</p>
                                    <p className="text-gray-500 text-sm mt-1">ou</p>
                                    <label htmlFor="file-upload" className="mt-2 inline-block bg-white text-blue-600 font-semibold py-2 px-4 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-100">Selecione um Arquivo</label>
                                    <p className="text-gray-500 text-sm mt-2">Você também pode colar com Ctrl+V</p>
                                </div>
                            ) : (
                                <div className="bg-white p-4 rounded-lg shadow-md border border-gray-200">
                                    <div className="flex justify-between items-center mb-2">
                                        <h2 className="text-lg font-semibold text-gray-800">Planilha Anexada</h2>
                                        <button onClick={() => {setImage(null); setExtractedData(null);}} className="text-red-500 hover:text-red-700 font-bold p-1 rounded-full transition-colors text-2xl leading-none">&times;</button>
                                    </div>
                                    <img src={image} alt="Planilha anexada" className="w-full h-auto rounded-md border" />
                                    <div className="mt-4 flex flex-col sm:flex-row gap-4">
                                        <button onClick={handleExtractData} disabled={isLoading} className="w-full bg-blue-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-blue-700 disabled:bg-blue-300 transition-colors flex items-center justify-center">
                                            {isLoading ? <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : 'Extrair Dados'}
                                        </button>
                                        {extractedData && <button onClick={handleOpenRateioConfig} className="w-full bg-green-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-green-700 transition-colors">Iniciar Rateio</button>}
                                    </div>
                                </div>
                            )}
                            {error && <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg" role="alert">{error}</div>}
                        </div>

                        {/* Coluna da Direita: Resultados */}
                        <div className="space-y-6">
                             {!isLoading && !extractedData && <WelcomePlaceholder />}
                            {extractedData && (
                                <>
                                    <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
                                        <h2 className="text-xl font-bold text-gray-900 mb-4">Visão de Contas do Reclamante</h2>
                                        <EditableField
                                            label="Valor Bruto do Reclamante"
                                            value={valorBrutoReclamante}
                                            onChange={(novoBruto) => {
                                                handleUpdateExtractedData('valorBrutoReclamante', novoBruto);
                                            }}
                                        />
                                        <hr className="my-3 border-gray-200" />
                                        <h3 className="text-md font-semibold text-gray-700 mb-2">DESCONTOS DO RECLAMANTE</h3>
                                        <div className="space-y-2">
                                            {extractedData.descontosReclamante.map((desconto, index) => (
                                                <EditableListItem
                                                    key={desconto.id}
                                                    item={desconto}
                                                    onDescriptionChange={(value) => handleUpdateListItem('descontosReclamante', index, 'descricao', value)}
                                                    onValueChange={(value) => handleUpdateListItem('descontosReclamante', index, 'valor', value)}
                                                    onDelete={() => handleDeleteListItem('descontosReclamante', index)}
                                                    valueClassName="text-red-600 font-semibold"
                                                />
                                            ))}
                                        </div>
                                        <div className="mt-3">
                                            <button onClick={() => handleAddListItem('descontosReclamante')} className="w-full text-sm text-blue-600 bg-blue-50 hover:bg-blue-100 font-semibold py-2 px-4 border border-dashed border-blue-300 rounded-lg">
                                                + Adicionar Desconto
                                            </button>
                                        </div>
                                        <hr className="my-3 border-t-2 border-gray-300" />
                                        <div className="flex justify-between items-baseline mt-4">
                                            <span className="font-bold text-gray-800">Valor Líquido a Receber:</span>
                                            <span className="font-mono text-lg font-bold text-green-600">{valorLiquidoFinal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                                        </div>
                                    </div>
                                    <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
                                        <h2 className="text-xl font-bold text-gray-900 mb-4">Débitos da Reclamada (Credores)</h2>
                                        <div className="space-y-2">
                                            {extractedData.reclamadaDebitos.map((debito, index) => (
                                                <EditableListItem
                                                    key={debito.id}
                                                    item={debito}
                                                    onDescriptionChange={(value) => handleUpdateListItem('reclamadaDebitos', index, 'descricao', value)}
                                                    onValueChange={(value) => handleUpdateListItem('reclamadaDebitos', index, 'valor', value)}
                                                    onDelete={() => handleDeleteListItem('reclamadaDebitos', index)}
                                                />
                                            ))}
                                        </div>
                                         <div className="mt-3">
                                            <button onClick={() => handleAddListItem('reclamadaDebitos')} className="w-full text-sm text-blue-600 bg-blue-50 hover:bg-blue-100 font-semibold py-2 px-4 border border-dashed border-blue-300 rounded-lg">
                                                + Adicionar Débito
                                            </button>
                                        </div>
                                    </div>
                                </>
                            )}
                        </div>
                    </div>
                </div>
            </div>
            {extractedData && (
                 <RateioModal 
                    isOpen={showRateioConfig} 
                    onClose={() => setShowRateioConfig(false)} 
                    initialRateioItems={rateioItems}
                    valorBrutoReclamante={valorBrutoReclamante}
                 />
            )}
        </>
    );
};

export default App;