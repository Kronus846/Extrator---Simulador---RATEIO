import React, { useState, useEffect, useRef } from 'react';
import type { RateioItem, RateioResultsData, Desconto } from '../types';
import { RateioCheckbox } from './RateioCheckbox';

interface RateioModalProps {
    isOpen: boolean;
    onClose: () => void;
    initialRateioItems: RateioItem[];
    valorBrutoReclamante: number;
}

export const RateioModal: React.FC<RateioModalProps> = ({ isOpen, onClose, initialRateioItems, valorBrutoReclamante }) => {
    const [deposito, setDeposito] = useState('');
    const [rateioItems, setRateioItems] = useState<RateioItem[]>(initialRateioItems);
    const [rateioResults, setRateioResults] = useState<RateioResultsData | null>(null);
    const [honorariosPercent, setHonorariosPercent] = useState('');
    const [honorariosCalculados, setHonorariosCalculados] = useState<Desconto | null>(null);
    const [copyButtonText, setCopyButtonText] = useState('Copiar Resultados');

    const modalRef = useRef<HTMLDivElement>(null);
    const [isDragging, setIsDragging] = useState(false);
    const [position, setPosition] = useState({ x: 0, y: 0 });
    const dragStartOffset = useRef({ x: 0, y: 0 });

    useEffect(() => {
        setRateioItems(initialRateioItems);
        setRateioResults(null);
        setHonorariosCalculados(null);
        setHonorariosPercent('');
        setDeposito('');
        setIsDragging(false);
        setPosition({ x: 0, y: 0 });
    }, [initialRateioItems, isOpen]);
    
    useEffect(() => {
        const handleMouseMove = (e: MouseEvent) => {
            if (!modalRef.current) return;
            e.preventDefault();
            setPosition({
                x: e.clientX - dragStartOffset.current.x,
                y: e.clientY - dragStartOffset.current.y,
            });
        };

        const handleMouseUp = () => {
            setIsDragging(false);
        };

        if (isDragging) {
            window.addEventListener('mousemove', handleMouseMove);
            window.addEventListener('mouseup', handleMouseUp);
        }

        return () => {
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('mouseup', handleMouseUp);
        };
    }, [isDragging]);

    const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
        if (modalRef.current) {
            e.preventDefault();
            const rect = modalRef.current.getBoundingClientRect();
            dragStartOffset.current = {
                x: e.clientX - rect.left,
                y: e.clientY - rect.top,
            };
            setIsDragging(true);
        }
    };

    if (!isOpen) {
        return null;
    }

    const formatCurrencyInput = (value: string) => {
        if (!value) return '';
        const digitsOnly = value.replace(/\D/g, '');
        if (digitsOnly === '') return '';

        const numberValue = parseInt(digitsOnly, 10) / 100;
        return new Intl.NumberFormat('pt-BR', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }).format(numberValue);
    };

    const handleDepositoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const formattedValue = formatCurrencyInput(e.target.value);
        setDeposito(formattedValue);
    };

    const handleToggleRateioItem = (id: string) => {
        setRateioItems(rateioItems.map(item => item.id === id ? { ...item, selecionado: !item.selecionado } : item));
    };
    
    const handleToggleAll = (selecionar: boolean) => {
        setRateioItems(rateioItems.map(item => ({...item, selecionado: selecionar})));
    };
    
    const handleCalculateHonorarios = () => {
        if (!valorBrutoReclamante || !honorariosPercent) {
            alert("Dados extraídos e percentual são necessários.");
            return;
        }
        const percent = parseFloat(honorariosPercent.replace(',', '.'));
        if (isNaN(percent) || percent < 0) {
            alert("Percentual inválido.");
            return;
        }
        const valorHonorarios = valorBrutoReclamante * (percent / 100);
        
        setHonorariosCalculados({
            descricao: 'Honorários Contratuais',
            valor: valorHonorarios
        });

        setRateioItems(prevItems => {
            const newItems = [...prevItems];
            const originalPrincipal = initialRateioItems.find(item => item.origem === 'principal');

            if (!originalPrincipal) return prevItems;

            const novoValorPrincipal = originalPrincipal.valorOriginal - valorHonorarios;
            
            const principalIndex = newItems.findIndex(item => item.origem === 'principal');
            if (principalIndex !== -1) {
                newItems[principalIndex] = { ...newItems[principalIndex], valorOriginal: novoValorPrincipal };
            }

            const honorariosIndex = newItems.findIndex(item => item.origem === 'honorarios');
            if (honorariosIndex !== -1) {
                newItems[honorariosIndex] = { ...newItems[honorariosIndex], valorOriginal: valorHonorarios, selecionado: true };
            } else {
                newItems.push({
                    id: 'honorarios_contratuais',
                    descricao: 'Honorários Contratuais',
                    valorOriginal: valorHonorarios,
                    selecionado: true,
                    origem: 'honorarios',
                });
            }
            return newItems;
        });
    }

    const handleCalculateRateio = () => {
        const valorDeposito = parseFloat(deposito.replace(/\./g, '').replace(',', '.'));
        if (isNaN(valorDeposito) || valorDeposito <= 0) {
            alert("Por favor, insira um valor de depósito válido.");
            return;
        }
    
        const itensSelecionados = rateioItems.filter(item => item.selecionado);
        if (itensSelecionados.length === 0) {
            alert("Selecione ao menos um item para o rateio.");
            return;
        }
    
        const somaItensSelecionados = itensSelecionados.reduce((acc, item) => acc + item.valorOriginal, 0);

        if (somaItensSelecionados <= 0) {
            const resultados = itensSelecionados.map(item => ({
                descricao: item.descricao,
                valorRateado: 0
            }));
            setRateioResults({
                resultados,
                totalDistribuido: 0,
                saldoRemanescente: valorDeposito
            });
            return;
        }
    
        let resultados = [];
        let totalDistribuido = 0;
    
        if (valorDeposito >= somaItensSelecionados) {
            resultados = itensSelecionados.map(item => ({
                descricao: item.descricao,
                valorRateado: item.valorOriginal
            }));
            totalDistribuido = somaItensSelecionados;
        } else {
            resultados = itensSelecionados.map(item => {
                const proporcao = item.valorOriginal / somaItensSelecionados;
                return {
                    descricao: item.descricao,
                    valorRateado: valorDeposito * proporcao
                };
            });
            totalDistribuido = valorDeposito;
        }
    
        setRateioResults({
            resultados,
            totalDistribuido,
            saldoRemanescente: valorDeposito - totalDistribuido
        });
    };

    const handleCopyResults = () => {
        if (!rateioResults) return;

        const { resultados, totalDistribuido, saldoRemanescente } = rateioResults;

        let textToCopy = "📊 Resultado do Rateio 📊\n";
        textToCopy += "--------------------------------------\n";

        resultados.forEach(res => {
            textToCopy += `${res.descricao}: ${res.valorRateado.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}\n`;
        });
        
        textToCopy += "--------------------------------------\n";
        textToCopy += `Total Distribuído: ${totalDistribuido.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}\n`;
        textToCopy += `Saldo Remanescente: ${saldoRemanescente.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}\n`;

        navigator.clipboard.writeText(textToCopy).then(() => {
            setCopyButtonText('Copiado!');
            setTimeout(() => setCopyButtonText('Copiar Resultados'), 2000);
        }).catch(err => {
            console.error('Failed to copy text: ', err);
            alert('Não foi possível copiar os resultados.');
        });
    };

    const modalStyle = position.x === 0 && position.y === 0 ? {} : { top: `${position.y}px`, left: `${position.x}px`, transform: 'none' };

    const reclamanteItems = rateioItems.filter(item => ['principal', 'reclamante', 'honorarios'].includes(item.origem));
    const reclamadaItems = rateioItems.filter(item => item.origem === 'reclamada');

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div
                ref={modalRef}
                className="fixed bg-white p-6 rounded-lg shadow-2xl border border-gray-200 w-full max-w-2xl top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
                style={modalStyle}
            >
                 <div className="flex justify-between items-center pb-4 border-b border-gray-200" onMouseDown={handleMouseDown} style={{ cursor: 'move' }}>
                    <h2 className="text-xl font-bold text-gray-900">Configurar Rateio Proporcional</h2>
                    <button onClick={onClose} className="text-gray-500 hover:text-gray-800 font-bold p-1 text-2xl" style={{ cursor: 'pointer' }}>&times;</button>
                </div>
                
                <div className="py-4 space-y-4 max-h-[60vh] overflow-y-auto pr-2">
                    <div>
                        <label htmlFor="deposito" className="block text-sm font-medium text-gray-700 mb-1">Valor do Depósito a Ratear</label>
                        <input
                            id="deposito"
                            type="text"
                            value={deposito}
                            onChange={handleDepositoChange}
                            placeholder="Ex: 7.585,30"
                            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        />
                    </div>

                     <div className="p-4 bg-gray-50 rounded-md border">
                         <h3 className="text-md font-semibold text-gray-800 mb-2">Calcular Honorários Contratuais</h3>
                        <div className="flex items-center gap-2">
                            <input
                                type="text"
                                value={honorariosPercent}
                                onChange={e => setHonorariosPercent(e.target.value)}
                                placeholder="Percentual (%)"
                                className="w-1/2 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                            />
                            <button onClick={handleCalculateHonorarios} className="w-1/2 bg-gray-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-gray-700 transition-colors">Calcular</button>
                        </div>
                        {honorariosCalculados && (
                            <p className="mt-2 text-sm text-gray-600">
                                Valor Calculado: <span className="font-bold">{honorariosCalculados.valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                            </p>
                        )}
                    </div>

                     <div className="flex justify-end gap-2 pt-4 border-t mt-4">
                        <button onClick={() => handleToggleAll(true)} className="text-sm text-blue-600 hover:underline">Marcar Todos</button>
                        <button onClick={() => handleToggleAll(false)} className="text-sm text-blue-600 hover:underline">Desmarcar Todos</button>
                    </div>

                    {reclamanteItems.length > 0 && (
                        <div className="mt-2">
                            <h3 className="text-md font-semibold text-gray-800 mb-2">Verbas do Reclamante</h3>
                            <div className="space-y-2">
                                {reclamanteItems.map(item => <RateioCheckbox key={item.id} item={item} onToggle={handleToggleRateioItem} />)}
                            </div>
                        </div>
                    )}

                    {reclamadaItems.length > 0 && (
                        <div className="mt-4 pt-4 border-t border-gray-200">
                            <h3 className="text-md font-semibold text-gray-800 mb-2">Débitos da Reclamada</h3>
                            <div className="space-y-2">
                                {reclamadaItems.map(item => <RateioCheckbox key={item.id} item={item} onToggle={handleToggleRateioItem} />)}
                            </div>
                        </div>
                    )}
                </div>

                <div className="pt-4 border-t border-gray-200">
                    <button onClick={handleCalculateRateio} className="w-full bg-green-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-green-700 transition-colors">
                        Calcular Rateio
                    </button>
                </div>
                
                {rateioResults && (
                     <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
                        <div className="flex justify-between items-center mb-3">
                            <h3 className="text-lg font-bold text-gray-900">Resultado do Rateio</h3>
                            <button
                                onClick={handleCopyResults}
                                className="bg-blue-100 text-blue-700 text-xs font-semibold py-1 px-3 rounded-full hover:bg-blue-200 transition-colors"
                            >
                                {copyButtonText}
                            </button>
                        </div>
                        <div className="space-y-2">
                             {rateioResults.resultados.map((res, index) => (
                                 <div key={index} className="flex justify-between items-baseline text-sm">
                                     <span className="text-gray-700">{res.descricao}</span>
                                     <span className="font-mono font-semibold text-gray-900">{res.valorRateado.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                                 </div>
                             ))}
                             <hr className="my-2 border-blue-200" />
                             <div className="flex justify-between items-baseline font-bold">
                                 <span className="text-gray-800">Total Distribuído:</span>
                                 <span className="font-mono text-gray-900">{rateioResults.totalDistribuido.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                             </div>
                             <div className="flex justify-between items-baseline font-bold">
                                 <span className="text-gray-800">Saldo Remanescente:</span>
                                 <span className={`font-mono ${rateioResults.saldoRemanescente > 0 ? 'text-orange-600' : 'text-gray-900'}`}>{rateioResults.saldoRemanescente.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                             </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};