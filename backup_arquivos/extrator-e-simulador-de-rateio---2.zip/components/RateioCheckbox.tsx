import React from 'react';
import type { RateioItem } from '../types';

interface RateioCheckboxProps {
  item: RateioItem;
  onToggle: (id: string) => void;
}

export const RateioCheckbox: React.FC<RateioCheckboxProps> = ({ item, onToggle }) => {
    return (
         <label htmlFor={item.id} className="flex items-center justify-between p-3 bg-white rounded-md border border-gray-200 hover:bg-gray-50 cursor-pointer transition-colors duration-200">
            <div className="flex items-center">
                <input
                    id={item.id}
                    type="checkbox"
                    checked={item.selecionado}
                    onChange={() => onToggle(item.id)}
                    className="h-5 w-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="ml-3 text-sm text-gray-700">{item.descricao}</span>
            </div>
            <span className="text-sm font-mono text-gray-800 font-medium">{item.valorOriginal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
        </label>
    );
};
