export interface Desconto {
  id?: string;
  descricao: string;
  valor: number;
}

export interface Debito {
  id?: string;
  descricao: string;
  valor: number;
}

export interface ExtractedData {
  valorBrutoReclamante: number;
  descontosReclamante: Desconto[];
  reclamadaDebitos: Debito[];
  contribuicaoSocialTotal: number;
}

export interface RateioItem {
  id: string;
  descricao: string;
  valorOriginal: number;
  selecionado: boolean;
  origem: 'reclamante' | 'reclamada' | 'principal' | 'honorarios';
}

export interface RateioResult {
    descricao: string;
    valorRateado: number;
}

export interface RateioResultsData {
    resultados: RateioResult[];
    totalDistribuido: number;
    saldoRemanescente: number;
}