export interface TimeSheetEntry {
  data: string;
  dia_semana: string;
  entradas_saidas: string[];
  horas_trabalhadas: string;
  observacao: string;
}

// FIX: Add Anomaly and SummaryReportData interfaces to resolve import errors in SummaryReport.tsx.
export interface Anomaly {
  type: string;
  date: string;
  description: string;
  fileName: string;
}

export interface SummaryReportData {
  totalFiles: number;
  totalWorkedHours: string;
  totalIntervalHours: string;
  anomalies: Anomaly[];
  observations: Record<string, number>;
}
