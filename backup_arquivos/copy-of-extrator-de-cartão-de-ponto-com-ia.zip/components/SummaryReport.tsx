import React from 'react';
import { SummaryReportData, Anomaly } from '../types';
import { DownloadIcon } from './icons/DownloadIcon';
import { AlertTriangleIcon } from './icons/AlertTriangleIcon';

interface SummaryReportProps {
    reportData: SummaryReportData;
    onDownload: () => void;
}

const AnomalyItem: React.FC<{anomaly: Anomaly}> = ({ anomaly }) => {
    const getAnomalyColor = () => {
        switch(anomaly.type) {
            case 'Horas Extras': return 'bg-blue-100 text-blue-800';
            case 'Falta Não Justificada': return 'bg-red-100 text-red-800';
            case 'Intervalo Curto': return 'bg-yellow-100 text-yellow-800';
            case 'Marcações Ímpares': return 'bg-purple-100 text-purple-800';
            default: return 'bg-gray-100 text-gray-800';
        }
    }
    return (
        <div className="border-l-4 border-yellow-400 bg-yellow-50 p-3 rounded-r-lg">
             <div className="flex items-start gap-3">
                 <AlertTriangleIcon className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-0.5"/>
                 <div>
                    <p className="font-semibold text-slate-800 text-sm">{anomaly.type}</p>
                    <p className="text-slate-600 text-sm">
                        <span className="font-medium">{anomaly.date}:</span> {anomaly.description}
                    </p>
                    <p className="text-xs text-slate-500 truncate" title={anomaly.fileName}>Arquivo: {anomaly.fileName}</p>
                </div>
             </div>
        </div>
    )
}

export const SummaryReport: React.FC<SummaryReportProps> = ({ reportData, onDownload }) => {
    const { totalFiles, totalWorkedHours, totalIntervalHours, anomalies, observations } = reportData;
    return (
        <aside className="mt-8 bg-white rounded-xl shadow-lg p-6 md:p-8 space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <h2 className="text-2xl font-bold text-slate-800">Relatório Consolidado Inteligente</h2>
                <button 
                    onClick={onDownload} 
                    className="flex items-center px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-sm hover:bg-teal-700 transition-all text-sm w-full sm:w-auto justify-center">
                    <DownloadIcon className="w-5 h-5 mr-2"/> Baixar Relatório
                </button>
            </div>

            {/* Totals */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-center">
                <div className="bg-slate-50 p-4 rounded-lg">
                    <p className="text-sm text-slate-500">Arquivos Processados</p>
                    <p className="text-2xl font-semibold text-slate-800">{totalFiles}</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-lg">
                    <p className="text-sm text-slate-500">Total Horas Trabalhadas</p>
                    <p className="text-2xl font-semibold text-slate-800">{totalWorkedHours}</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-lg col-span-2 md:col-span-1">
                    <p className="text-sm text-slate-500">Total Horas de Intervalo</p>
                    <p className="text-2xl font-semibold text-slate-800">{totalIntervalHours}</p>
                </div>
            </div>

             {/* Anomalies */}
            <div>
                <h3 className="text-lg font-semibold text-slate-700 mb-3">Anomalias e Pontos de Atenção</h3>
                {anomalies.length > 0 ? (
                    <div className="space-y-3 max-h-60 overflow-y-auto pr-2">
                        {anomalies.map((anomaly, index) => <AnomalyItem key={index} anomaly={anomaly} />)}
                    </div>
                ) : (
                    <div className="text-center py-6 bg-slate-50 rounded-lg">
                        <p className="text-slate-600">Nenhuma anomalia detectada. Bom trabalho!</p>
                    </div>
                )}
            </div>

             {/* Observations */}
             {Object.keys(observations).length > 0 && (
                <div>
                    <h3 className="text-lg font-semibold text-slate-700 mb-3">Observações Relevantes</h3>
                    <div className="flex flex-wrap gap-2">
                         {Object.entries(observations).map(([obs, count]) => (
                            <span key={obs} className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-gray-100 text-gray-800">
                                {obs}
                                <span className="ml-2 inline-block py-0.5 px-2 text-xs font-bold text-gray-700 bg-gray-200 rounded-full">{
                                    // FIX: Explicitly convert count to a string to resolve the 'Type 'unknown' is not assignable to type 'ReactNode'' error.
                                    String(count)
                                }</span>
                            </span>
                         ))}
                    </div>
                </div>
             )}
        </aside>
    );
};
