import React from 'react';

export const Spinner: React.FC = () => {
    return (
        <div
            className="w-6 h-6 rounded-full animate-spin border-2 border-solid border-teal-500 border-t-transparent"
            role="status"
            aria-label="loading"
        ></div>
    );
};
