import React, { useCallback, useState } from 'react';
import { UploadCloudIcon } from './icons/UploadCloudIcon';

interface DropzoneProps {
    onFileDrop: (files: File[]) => void;
    disabled: boolean;
}

export const Dropzone: React.FC<DropzoneProps> = ({ onFileDrop, disabled }) => {
    const [isDragging, setIsDragging] = useState(false);

    const handleDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        if (!disabled) setIsDragging(true);
    };

    const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);
    };

    const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
    };

    const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);

        if (disabled) return;

        const files = e.dataTransfer.files;
        if (files && files.length > 0) {
            const pdfFiles = Array.from(files).filter(file => file.type === 'application/pdf');
            if(pdfFiles.length > 0) {
                onFileDrop(pdfFiles);
            } else {
                alert("Por favor, envie apenas arquivos PDF.");
            }
        }
    }, [onFileDrop, disabled]);
    
    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const files = e.target.files;
        if (files && files.length > 0) {
            const pdfFiles = Array.from(files).filter(file => file.type === 'application/pdf');
            if(pdfFiles.length > 0) {
                onFileDrop(pdfFiles);
            } else {
                alert("Por favor, envie apenas arquivos PDF.");
            }
        }
    };

    const dragDropClasses = isDragging
        ? 'border-teal-500 bg-teal-50'
        : 'border-slate-300 bg-slate-50 hover:border-teal-400 hover:bg-teal-50';

    return (
        <div
            className={`relative flex flex-col items-center justify-center p-8 md:p-12 border-2 border-dashed rounded-lg text-center transition-all duration-300 ${dragDropClasses}`}
            onDragEnter={handleDragEnter}
            onDragLeave={handleDragLeave}
            onDragOver={handleDragOver}
            onDrop={handleDrop}
        >
            <input
                type="file"
                id="file-upload"
                className="absolute w-full h-full opacity-0 cursor-pointer"
                accept="application/pdf"
                onChange={handleFileChange}
                disabled={disabled}
                multiple
            />
            <UploadCloudIcon className="w-12 h-12 text-slate-400 mb-4" />
            <p className="text-slate-700 font-semibold">
                Arraste e solte os PDFs dos cartões de ponto aqui
            </p>
            <p className="text-slate-500 mt-1">ou</p>
            <label
                htmlFor="file-upload"
                className="mt-2 text-teal-600 font-semibold cursor-pointer hover:underline"
            >
                clique para selecionar os arquivos
            </label>
            <p className="text-xs text-slate-400 mt-4">Apenas arquivos .PDF são aceitos</p>
        </div>
    );
};