import { GoogleGenAI, Type } from "@google/genai";
import { TimeSheetEntry } from '../types';

// FIX: Initialize GoogleGenAI directly with process.env.API_KEY as per guidelines.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const timeSheetSchema = {
    type: Type.ARRAY,
    items: {
      type: Type.OBJECT,
      properties: {
        data: {
          type: Type.STRING,
          description: 'A data do registro no formato DD/MM/AAAA.',
        },
        dia_semana: {
          type: Type.STRING,
          description: 'O dia da semana (ex: Segunda-feira, Terça-feira).',
        },
        entradas_saidas: {
            type: Type.ARRAY,
            description: 'Uma lista com todos os horários de entrada e saída do dia.',
            items: { type: Type.STRING },
        },
        horas_trabalhadas: {
            type: Type.STRING,
            description: 'O total de horas trabalhadas no dia. Se não houver, retornar "00:00".',
        },
        observacao: {
            type: Type.STRING,
            description: "Qualquer observação relevante para o dia, como 'Férias', 'Folga', 'Atestado Médico', 'Abono', 'Permuta', 'Trabalho em Domingo', 'Trabalho em Feriado'. Se não houver, retornar uma string vazia.",
        },
      },
      required: ['data', 'dia_semana', 'entradas_saidas', 'horas_trabalhadas', 'observacao'],
    },
};

const systemInstruction = `Você é um assistente de RH especialista em analisar cartões de ponto de funcionários. Sua tarefa é extrair as informações de cada dia do cartão de ponto fornecido na imagem. Siga estas regras estritamente:
1.  Extraia todas as linhas que contenham datas e horários.
2.  Para cada dia, identifique a data, o dia da semana, todos os horários de entrada e saída em ordem cronológica, e o total de horas trabalhadas.
3.  Identifique e anote na observação se o dia foi um Sábado, Domingo ou Feriado com horas trabalhadas.
4.  Identifique e anote na observação eventos especiais como 'Férias', 'Folga', 'Abono da Chefia', 'Atestado Médico', 'Permuta', etc.
5.  Se um dia não tiver registros de ponto (comum em sábados, domingos, feriados ou dias com justificativa como 'Férias'), a lista de 'entradas_saidas' deve ser um array vazio e 'horas_trabalhadas' deve ser "00:00". A 'observacao' deve conter a razão (ex: 'Sábado', 'Domingo', 'Férias').
6.  Retorne os dados em um array JSON, seguindo exatamente o schema fornecido. Não adicione nenhum outro texto ou explicação na sua resposta.`;

export async function extractTimeSheetData(imagesBase64: string[], signal: AbortSignal): Promise<TimeSheetEntry[]> {
    signal.throwIfAborted();
    
    const imageParts = imagesBase64.map(img => ({
        inlineData: {
            mimeType: 'image/jpeg',
            data: img,
        },
    }));

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: { parts: [...imageParts] },
        config: {
            systemInstruction,
            responseMimeType: "application/json",
            responseSchema: timeSheetSchema,
        },
    });
    
    signal.throwIfAborted();

    const jsonText = response.text.trim();
    try {
        const parsedData = JSON.parse(jsonText);
        // Basic validation
        if (Array.isArray(parsedData)) {
            return parsedData as TimeSheetEntry[];
        }
        throw new Error("A resposta da IA não é um array válido.");
    } catch (e) {
        console.error("Erro ao parsear JSON da resposta da IA:", e);
        console.error("Resposta recebida:", jsonText);
        throw new Error("Formato de resposta inválido da IA.");
    }
}
