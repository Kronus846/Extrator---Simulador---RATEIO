import React, { useState, useCallback, useRef } from 'react';
import { Dropzone } from './components/Dropzone';
import { Spinner } from './components/Spinner';
import { FileTextIcon } from './components/icons/FileTextIcon';
import { DownloadIcon } from './components/icons/DownloadIcon';
import { TrashIcon } from './components/icons/TrashIcon';
import { StopCircleIcon } from './components/icons/StopCircleIcon';
import { RotateCwIcon } from './components/icons/RotateCwIcon';
import { PlusCircleIcon } from './components/icons/PlusCircleIcon';
import { TimeSheetEntry } from './types';
import { extractTimeSheetData } from './services/geminiService';
import { convertPdfToImages } from './utils/fileHelpers';

// Make external libraries available from CDN
declare const XLSX: any;

// Helper function to convert "HH:MM" to total minutes from midnight
const timeToMinutes = (timeStr: string): number => {
    if (!timeStr || !/^\d{2}:\d{2}$/.test(timeStr)) {
        return 0;
    }
    const [hours, minutes] = timeStr.split(':').map(Number);
    return hours * 60 + minutes;
};

// Helper function to convert total minutes back to "HH:MM" format
const minutesToTime = (totalMinutes: number): string => {
    if (isNaN(totalMinutes) || totalMinutes <= 0) {
        return "00:00";
    }
    const hours = Math.floor(totalMinutes / 60);
    const minutes = Math.round(totalMinutes % 60);
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
};

// Helper function to parse DD/MM/AAAA date string to a Date object for sorting
const parseDate = (dateStr: string): Date => {
    const [day, month, year] = dateStr.split('/').map(Number);
    // Month is 0-indexed in JavaScript Date
    return new Date(year, month - 1, day);
};


interface ProcessedFile {
  id: string;
  file: File;
  status: 'processing' | 'success' | 'error';
  processingStatusText?: string;
  extractedData?: TimeSheetEntry[] | null;
  error?: string | null;
}

const App: React.FC = () => {
    const [processedFiles, setProcessedFiles] = useState<ProcessedFile[]>([]);
    const abortControllersRef = useRef(new Map<string, AbortController>());
    const fileInputRef = useRef<HTMLInputElement>(null);

    const processFile = useCallback(async (file: File, fileId: string) => {
        const controller = new AbortController();
        abortControllersRef.current.set(fileId, controller);

        const updateStatus = (text: string) => {
            setProcessedFiles(current =>
                current.map(f => f.id === fileId ? { ...f, status: 'processing', processingStatusText: text } : f)
            );
        };

        try {
            updateStatus('Lendo o arquivo PDF...');
            const images = await convertPdfToImages(file, controller.signal);
            if (controller.signal.aborted) throw new DOMException('Aborted by user', 'AbortError');
            if (images.length === 0) throw new Error("Não foi possível extrair imagens do PDF.");

            updateStatus('Analisando dados com IA...');
            const data = await extractTimeSheetData(images, controller.signal);
            if (controller.signal.aborted) throw new DOMException('Aborted by user', 'AbortError');
            if (!data || data.length === 0) throw new Error("A IA não conseguiu extrair dados. Verifique o formato.");

            setProcessedFiles(current =>
                current.map(f => f.id === fileId ? { ...f, status: 'success', extractedData: data, processingStatusText: 'Concluído!' } : f)
            );
        } catch (err: any) {
            if (err.name === 'AbortError') {
                console.log(`Processo ${fileId} cancelado.`);
                return;
            }
            console.error(err);
            const errorMessage = err instanceof Error ? err.message : 'Ocorreu um erro desconhecido.';
            setProcessedFiles(current =>
                current.map(f => f.id === fileId ? { ...f, status: 'error', error: `Falha: ${errorMessage}` } : f)
            );
        } finally {
            abortControllersRef.current.delete(fileId);
        }
    }, []);

    const handleFilesProcess = useCallback((selectedFiles: File[]) => {
        // Sort files by name chronologically before processing
        const sortedFiles = selectedFiles.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));

        const newFiles: ProcessedFile[] = sortedFiles.map(file => {
            const newFile: ProcessedFile = {
                id: crypto.randomUUID(),
                file,
                status: 'processing',
                processingStatusText: 'Iniciando...',
            };
            processFile(file, newFile.id);
            return newFile;
        });

        setProcessedFiles(current => [...current, ...newFiles]);
    }, [processFile]);

    const handleDelete = (fileId: string) => {
        const controller = abortControllersRef.current.get(fileId);
        if (controller) {
            controller.abort();
            abortControllersRef.current.delete(fileId);
        }
        setProcessedFiles(current => current.filter(f => f.id !== fileId));
    };

    const handleRetry = (fileId: string) => {
        const fileToRetry = processedFiles.find(f => f.id === fileId)?.file;
        if (!fileToRetry) return;

        setProcessedFiles(current =>
            current.map(f => f.id === fileId ? {
                ...f,
                status: 'processing',
                error: null,
                extractedData: null,
                processingStatusText: 'Reiniciando...'
            } : f)
        );
        processFile(fileToRetry, fileId);
    };
    
    const handleClearAll = () => {
        processedFiles.forEach(f => {
            const controller = abortControllersRef.current.get(f.id);
            if (controller) {
                controller.abort();
            }
        });
        abortControllersRef.current.clear();
        setProcessedFiles([]);
    };

    const handleAddMoreFiles = () => {
        fileInputRef.current?.click();
    };
    
    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const files = e.target.files;
        if (files && files.length > 0) {
            const pdfFiles = Array.from(files).filter(file => file.type === 'application/pdf');
            if (pdfFiles.length > 0) {
                handleFilesProcess(pdfFiles);
            } else {
                alert("Por favor, envie apenas arquivos PDF.");
            }
        }
        e.target.value = '';
    };

    const generateSheetData = (entries: TimeSheetEntry[], sourceFile?: string) => {
        const maxEntries = entries.reduce((max, entry) => Math.max(max, entry.entradas_saidas.length), 0);
        
        const dataForSheet = entries.map(entry => {
            const row: {[key: string]: any} = { 'Data': entry.data, 'Dia da Semana': entry.dia_semana };
            
            // Add source file column if provided
            if(sourceFile) {
                row['Arquivo de Origem'] = sourceFile;
            }

            for (let i = 0; i < maxEntries; i++) {
                row[i % 2 === 0 ? `Entrada ${Math.floor(i / 2) + 1}` : `Saída ${Math.floor(i / 2) + 1}`] = entry.entradas_saidas[i] || '';
            }
            
            let totalWorkedMinutes = 0;
            // Iterate over entries in pairs (entry/exit).
            // This correctly handles overnight shifts.
            for (let i = 0; i < entry.entradas_saidas.length - 1; i += 2) {
                const entrada = entry.entradas_saidas[i];
                const saida = entry.entradas_saidas[i + 1];

                if (entrada && saida) {
                    const entradaMinutes = timeToMinutes(entrada);
                    const saidaMinutes = timeToMinutes(saida);

                    if (saidaMinutes < entradaMinutes) {
                        // Overnight shift (e.g., enters at 22:00, exits at 06:00)
                        totalWorkedMinutes += ((24 * 60) - entradaMinutes) + saidaMinutes;
                    } else {
                        // Regular shift within the same day
                        totalWorkedMinutes += saidaMinutes - entradaMinutes;
                    }
                }
            }

            let totalIntervalMinutes = 0;
            for (let i = 1; i < entry.entradas_saidas.length - 1; i += 2) {
                if (entry.entradas_saidas[i] && entry.entradas_saidas[i + 1]) totalIntervalMinutes += (timeToMinutes(entry.entradas_saidas[i + 1]) - timeToMinutes(entry.entradas_saidas[i]));
            }

            row['Horas de Intervalo'] = minutesToTime(totalIntervalMinutes);
            row['Horas Trabalhadas'] = minutesToTime(totalWorkedMinutes);
            row['Observação'] = entry.observacao;
            return row;
        });

        const header = ['Data', 'Dia da Semana'];
        if(sourceFile) header.push('Arquivo de Origem');

        for (let i = 0; i < maxEntries; i++) header.push(i % 2 === 0 ? `Entrada ${Math.floor(i / 2) + 1}` : `Saída ${Math.floor(i / 2) + 1}`);
        header.push('Horas de Intervalo', 'Horas Trabalhadas', 'Observação');

        const colWidths = [{ wch: 12 }, { wch: 15 }];
        if(sourceFile) colWidths.push({ wch: 30 });
        for (let i = 0; i < maxEntries; i++) colWidths.push({ wch: 10 });
        colWidths.push({ wch: 18 }, { wch: 18 }, { wch: 40 });

        return { dataForSheet, header, colWidths, maxEntries };
    }

    const handleDownload = (processedFile: ProcessedFile) => {
        if (!processedFile.extractedData) return;
        const { extractedData, file } = processedFile;
        const { dataForSheet, header, colWidths } = generateSheetData(extractedData);
        
        const worksheet = XLSX.utils.json_to_sheet(dataForSheet, { header: header });
        worksheet['!cols'] = colWidths;
        
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, 'Cartão de Ponto');

        XLSX.writeFile(workbook, file.name.replace(/\.pdf$/i, '.xlsx') || 'cartao_de_ponto.xlsx');
    };

    const handleDownloadAll = () => {
        const successfulFiles = processedFiles.filter(f => f.status === 'success' && f.extractedData);
        if (successfulFiles.length === 0) return;

        let allEntries: (TimeSheetEntry & { sourceFile: string })[] = [];
        successfulFiles.forEach(pf => {
            if(pf.extractedData) {
                const entriesWithSource = pf.extractedData.map(entry => ({
                    ...entry,
                    sourceFile: pf.file.name,
                }));
                allEntries.push(...entriesWithSource);
            }
        });

        // Sort all entries by date chronologically
        allEntries.sort((a, b) => parseDate(a.data).getTime() - parseDate(b.data).getTime());

        const { dataForSheet, header, colWidths } = generateSheetData(allEntries, 'placeholder'); // Pass placeholder to include source file column

        const worksheet = XLSX.utils.json_to_sheet(dataForSheet, { header: header });
        worksheet['!cols'] = colWidths;
        
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, 'Consolidado');

        XLSX.writeFile(workbook, 'Cartoes_de_Ponto_Consolidado.xlsx');
    };

    const renderFileItem = (pf: ProcessedFile) => {
        const getStatusColor = () => {
            switch(pf.status) {
                case 'success': return 'border-green-500';
                case 'error': return 'border-red-500';
                case 'processing': return 'border-blue-500';
                default: return 'border-slate-300';
            }
        };

        return (
            <div key={pf.id} className={`bg-white border-l-4 ${getStatusColor()} rounded-lg shadow p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4`}>
                <div className="flex items-center min-w-0 flex-1">
                    <FileTextIcon className="w-6 h-6 mr-3 text-slate-500 flex-shrink-0"/>
                    <div className="min-w-0">
                       <p className="font-medium text-slate-800 truncate" title={pf.file.name}>{pf.file.name}</p>
                       {pf.status === 'processing' && <p className="text-sm text-slate-500">{pf.processingStatusText}</p>}
                       {pf.status === 'success' && <p className="text-sm text-green-600">Pronto para baixar!</p>}
                       {pf.status === 'error' && <p className="text-sm text-red-600 truncate" title={pf.error}>{pf.error}</p>}
                    </div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0 self-end sm:self-center">
                    {pf.status === 'processing' && (
                       <>
                         <Spinner />
                         <button onClick={() => handleDelete(pf.id)} className="p-2 text-slate-500 hover:text-red-600 rounded-full hover:bg-red-100 transition-colors" aria-label="Cancelar">
                             <StopCircleIcon className="w-6 h-6" />
                         </button>
                       </>
                    )}
                    {pf.status === 'success' && (
                       <>
                        <button onClick={() => handleDownload(pf)} className="flex items-center px-3 py-1.5 bg-teal-600 text-white text-sm font-semibold rounded-md shadow-sm hover:bg-teal-700 transition-colors">
                            <DownloadIcon className="w-4 h-4 mr-1.5"/> Baixar
                        </button>
                        <button onClick={() => handleDelete(pf.id)} className="p-2 text-slate-500 hover:text-red-600 rounded-full hover:bg-red-100 transition-colors" aria-label="Excluir">
                             <TrashIcon className="w-5 h-5" />
                        </button>
                       </>
                    )}
                    {pf.status === 'error' && (
                        <>
                        <button onClick={() => handleRetry(pf.id)} className="flex items-center px-3 py-1.5 bg-slate-600 text-white text-sm font-semibold rounded-md shadow-sm hover:bg-slate-700 transition-colors">
                            <RotateCwIcon className="w-4 h-4 mr-1.5"/> Tentar Novamente
                        </button>
                        <button onClick={() => handleDelete(pf.id)} className="p-2 text-slate-500 hover:text-red-600 rounded-full hover:bg-red-100 transition-colors" aria-label="Excluir">
                             <TrashIcon className="w-5 h-5" />
                        </button>
                       </>
                    )}
                </div>
            </div>
        );
    };

    const hasSuccessfulFiles = processedFiles.some(f => f.status === 'success');

    return (
        <div className="min-h-screen flex items-center justify-center bg-slate-100 p-4 font-sans">
            <div className="w-full max-w-3xl">
                 <input
                    type="file"
                    ref={fileInputRef}
                    className="hidden"
                    accept="application/pdf"
                    multiple
                    onChange={handleFileChange}
                />
                <header className="text-center mb-8">
                    <h1 className="text-4xl font-bold text-slate-800">Extrator de Cartão de Ponto</h1>
                    <p className="text-slate-600 mt-2">Converta múltiplos cartões de ponto em PDF para Excel com o poder da IA</p>
                </header>

                <main className="bg-white rounded-xl shadow-lg p-6 md:p-8 space-y-6">
                    {processedFiles.length === 0 ? (
                        <Dropzone onFileDrop={handleFilesProcess} disabled={false} />
                    ) : (
                        <div>
                            <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
                                <h2 className="text-xl font-semibold text-slate-700">Arquivos para Processar</h2>
                                <div className="flex flex-wrap gap-2">
                                    <button onClick={handleAddMoreFiles} className="flex items-center px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-sm hover:bg-teal-700 transition-all text-sm">
                                        <PlusCircleIcon className="w-5 h-5 mr-2"/> Adicionar mais
                                    </button>
                                     <button 
                                        onClick={handleDownloadAll} 
                                        disabled={!hasSuccessfulFiles}
                                        className="flex items-center px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg shadow-sm hover:bg-blue-700 transition-all text-sm disabled:bg-slate-300 disabled:cursor-not-allowed">
                                        <DownloadIcon className="w-5 h-5 mr-2"/> Baixar Todos
                                    </button>
                                     <button onClick={handleClearAll} className="px-4 py-2 bg-slate-200 text-slate-800 font-semibold rounded-lg hover:bg-slate-300 transition-colors text-sm">
                                        Limpar Tudo
                                    </button>
                                </div>
                            </div>
                            <div className="space-y-4">
                                {processedFiles.map(renderFileItem)}
                            </div>
                        </div>
                    )}
                </main>
                
                 <footer className="text-center mt-8 text-sm text-slate-500">
                    <p>Powered by Gemini API</p>
                </footer>
            </div>
        </div>
    );
};

export default App;