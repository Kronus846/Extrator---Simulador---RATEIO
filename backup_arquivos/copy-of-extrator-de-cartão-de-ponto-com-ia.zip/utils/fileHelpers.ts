// Make pdfjsLib available from CDN
declare const pdfjsLib: any;

if (typeof pdfjsLib !== 'undefined') {
    pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.3.136/pdf.worker.min.mjs`;
}

export const convertPdfToImages = async (file: File, signal: AbortSignal): Promise<string[]> => {
    if (typeof pdfjsLib === 'undefined') {
        throw new Error("A biblioteca PDF.js não foi carregada. Verifique a conexão com a internet.");
    }

    signal.throwIfAborted();

    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    const numPages = pdf.numPages;
    const imageBase64Strings: string[] = [];

    for (let i = 1; i <= numPages; i++) {
        signal.throwIfAborted();
        
        const page = await pdf.getPage(i);
        const viewport = page.getViewport({ scale: 2.0 }); // Higher scale for better OCR quality
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        if(!context) {
            console.warn(`Could not get canvas context for page ${i}`);
            continue;
        }

        canvas.height = viewport.height;
        canvas.width = viewport.width;

        const renderContext = {
            canvasContext: context,
            viewport: viewport,
        };

        await page.render(renderContext).promise;
        const dataUrl = canvas.toDataURL('image/jpeg', 0.9); // Use JPEG for smaller size
        // remove the "data:image/jpeg;base64," prefix
        imageBase64Strings.push(dataUrl.split(',')[1]);
    }

    return imageBase64Strings;
};